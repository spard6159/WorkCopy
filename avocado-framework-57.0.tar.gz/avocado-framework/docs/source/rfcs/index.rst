===========================
Request For Comments (RFCs)
===========================

The following list contains archivals of accepted, Request For
Comments posted and discussed on the `Avocado Devel Mailing List`_.

.. toctree::
   :maxdepth: 1

   LongTermStability

.. _Avocado Devel Mailing List: https://www.redhat.com/mailman/listinfo/avocado-devel
