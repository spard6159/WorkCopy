Other Resources
===============

This is a collection of some other varied Avocado related sources on
the web:

* Mindmap from 2015 workshop demonstrating features and examples
  are available `here <https://www.mindmeister.com/504616310>`__.

