#include <stdio.h>

int main(int argc, char *argv[])
{
    int a = 0;
    printf("MY VARIABLE 'A' IS: %x\n", a);
    return 0;
}
