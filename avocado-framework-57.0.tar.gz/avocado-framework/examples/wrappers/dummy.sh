#!/bin/bash
#
# Just exec the process.
#

exec -- "$@"
